Install nodeJS

VSCode plugins:
- live server
- live preview
- prettier code formatter
- css language features
- HTML language features
- Tailwind CSS intellisen\se
- Simple browser
- Debugger for chrome
